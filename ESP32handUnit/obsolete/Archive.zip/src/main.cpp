#include <Arduino.h>
#include <Wire.h>
#include <FastLED.h>
#include <PN532_I2C.h>
#include <PN532.h>
#include <VL53L0X.h>
#include "Config.h"

// ═══════════════════════════════════════════════════════════════
// ARCHITECTURE
//
//  Core 1 (loop) — smooth 50Hz+
//    VL53L0X on Wire  (GPIO5/6) — non-blocking continuous reads
//    LED animation, motor proximity, CLI
//
//  Core 0 (nfcTask) — runs independently
//    PN532 on Wire1 (GPIO7/8) — blocks 50ms per poll, isolated
//    Posts tag UIDs to nfcQueue → main loop reads non-blocking
//
//  Motor — esp_timer ISR, fires independently of both cores
// ═══════════════════════════════════════════════════════════════

PN532_I2C pn532i2c(Wire1);
PN532     nfc(pn532i2c);
VL53L0X   tof;

bool nfcReady = false;
bool tofReady = false;

QueueHandle_t nfcQueue;

// ── Motor ─────────────────────────────────────────────────────
struct MotorBurst {
    volatile bool     active  = false;
    volatile uint8_t  pulses  = 0;
    volatile uint8_t  done    = 0;
    volatile uint8_t  duty    = 0;
    volatile uint16_t onMs    = 0;
    volatile uint16_t offMs   = 0;
    volatile bool     motorOn = false;
} motorBurst;

esp_timer_handle_t motorTimer;

void IRAM_ATTR motorTimerCb(void*) {
    if (!motorBurst.active) return;
    if (motorBurst.motorOn) {
        ledcWrite(MOTOR_CH, 0);
        motorBurst.motorOn = false;
        esp_timer_start_once(motorTimer, motorBurst.offMs * 1000ULL);
    } else {
        if (++motorBurst.done >= motorBurst.pulses) {
            motorBurst.active = false; return;
        }
        ledcWrite(MOTOR_CH, motorBurst.duty);
        motorBurst.motorOn = true;
        esp_timer_start_once(motorTimer, motorBurst.onMs * 1000ULL);
    }
}

void motorBurstStart(uint8_t pulses = 3, uint8_t duty = 200,
                     uint16_t onMs = 55, uint16_t offMs = 35) {
    esp_timer_stop(motorTimer);
    motorBurst.active  = true;  motorBurst.pulses  = pulses;
    motorBurst.done    = 0;     motorBurst.duty    = duty;
    motorBurst.onMs    = onMs;  motorBurst.offMs   = offMs;
    motorBurst.motorOn = true;
    ledcWrite(MOTOR_CH, duty);
    esp_timer_start_once(motorTimer, onMs * 1000ULL);
}

void motorProxSet(uint8_t duty) {
    if (!motorBurst.active) ledcWrite(MOTOR_CH, duty);
}

// ── NFC task — Core 0 ─────────────────────────────────────────
char nfcLastUid[20] = {};
bool nfcTagPresent  = false;

void nfcReinit() {
    Serial.println("[NFC] reinitialising...");
    digitalWrite(NFC_RST_PIN, LOW);  vTaskDelay(pdMS_TO_TICKS(10));
    digitalWrite(NFC_RST_PIN, HIGH); vTaskDelay(pdMS_TO_TICKS(150));
    nfc.begin();
    uint32_t ver = nfc.getFirmwareVersion();
    if (!ver) { Serial.println("[NFC] reinit failed"); nfcReady = false; return; }
    nfc.SAMConfig();
    nfc.setPassiveActivationRetries(0xFF);
    nfcReady = true;
    Serial.printf("[NFC] reinit ok fw %u.%u\n", (ver>>16)&0xFF, (ver>>8)&0xFF);
}

void nfcTask(void*) {
    uint32_t lastSuccessMs = millis();
    for (;;) {
        if (millis() - lastSuccessMs > 5000) {
            nfcReinit();
            lastSuccessMs = millis();
        }
        uint8_t uid[7] = {}, len = 0;
        bool found = nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &len, 50);
        lastSuccessMs = millis();
        if (!found || len == 0) {
            if (nfcTagPresent) { nfcTagPresent = false; nfcLastUid[0] = '\0'; }
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        char s[20] = {};
        for (uint8_t i = 0; i < len; i++) sprintf(s + i*2, "%02X", uid[i]);
        s[len*2] = '\0';
        if (nfcTagPresent && strcmp(s, nfcLastUid) == 0) {
            vTaskDelay(pdMS_TO_TICKS(20)); continue;
        }
        nfcTagPresent = true;
        strlcpy(nfcLastUid, s, sizeof(nfcLastUid));
        xQueueSend(nfcQueue, s, 0);
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

// ── LED ───────────────────────────────────────────────────────
CRGB leds[LED_COUNT];
void ledSolid(CRGB c) { fill_solid(leds, LED_COUNT, c); FastLED.show(); }
void ledOff()          { FastLED.clear(true); }

enum class LedMode  { IDLE, RAINBOW, SOLID, OFF };
LedMode  ledMode    = LedMode::IDLE;
CRGB     solidColor = CRGB::Black;
uint8_t  rainbowHue = 0;

// ── Touch / connection state ───────────────────────────────────
// IDLE:     proximity drives motor + LED colour
// RELEASED: motor silent, LED stays teal, no new connections
//           until silence expires AND object has left the field
enum class TouchState { IDLE, RELEASED };
TouchState touchState   = TouchState::IDLE;
uint32_t   silenceUntil = 0;     // ms — silence active until this time
#define    SILENCE_MS   3000     // ms of motor silence after connection

// ── Distance ──────────────────────────────────────────────────
uint16_t lastDist = 9999;
inline bool distValid(uint16_t d) { return d >= 50 && d <= 2000; }

// ── CLI ───────────────────────────────────────────────────────
char    cliBuf[64] = {};
uint8_t cliPos     = 0;
bool    streaming  = false;

void printHelp() {
    Serial.println(
        "\nCommands:\n"
        "  status            — sensors + system state\n"
        "  stream            — toggle VL53L0X stream\n"
        "  scan              — I2C scan (both buses)\n"
        "  rainbow           — LED rainbow\n"
        "  solid <r> <g> <b> — solid colour\n"
        "  bright <0-255>    — brightness\n"
        "  off / idle        — LED modes\n"
        "  motor <pulses>    — trigger burst\n"
    );
}

void handleCommand(const char* cmd) {
    if (strcmp(cmd, "status") == 0) {
        Serial.printf("NFC  %s  last: %s\n", nfcReady?"ok":"fail",
                      nfcLastUid[0] ? nfcLastUid : "none");
        Serial.printf("TOF  %s  dist: %u mm\n", tofReady?"ok":"fail", lastDist);
        Serial.printf("LED  mode:%d  bright:%u\n",
                      (int)ledMode, FastLED.getBrightness());
        Serial.printf("Touch: %s%s\n",
                      touchState==TouchState::RELEASED?"RELEASED":"IDLE",
                      touchState==TouchState::RELEASED
                        ? (millis()<silenceUntil?" (silence)":" (waiting for separation)") : "");
    } else if (strcmp(cmd, "stream") == 0) {
        streaming = !streaming;
        Serial.printf("Stream: %s\n", streaming ? "ON" : "OFF");
    } else if (strcmp(cmd, "scan") == 0) {
        Serial.println("Wire (TOF bus):");
        for (uint8_t a = 1; a < 127; a++) {
            Wire.beginTransmission(a);
            if (Wire.endTransmission() == 0)
                Serial.printf("  0x%02X%s\n", a, a==0x29?" ← VL53L0X":"");
        }
        Serial.println("Wire1 (NFC bus):");
        for (uint8_t a = 1; a < 127; a++) {
            Wire1.beginTransmission(a);
            if (Wire1.endTransmission() == 0)
                Serial.printf("  0x%02X%s\n", a, a==0x24?" ← PN532":"");
        }
    } else if (strcmp(cmd, "rainbow") == 0) {
        ledMode = LedMode::RAINBOW;
    } else if (strcmp(cmd, "off") == 0) {
        ledMode = LedMode::OFF; ledOff();
    } else if (strcmp(cmd, "idle") == 0) {
        ledMode = LedMode::IDLE;
    } else if (strncmp(cmd, "solid", 5) == 0) {
        int r=0,g=0,b=0;
        if (sscanf(cmd+6, "%d %d %d", &r, &g, &b) == 3) {
            solidColor = CRGB(r,g,b); ledMode = LedMode::SOLID; ledSolid(solidColor);
        } else Serial.println("Usage: solid <r> <g> <b>");
    } else if (strncmp(cmd, "bright", 6) == 0) {
        FastLED.setBrightness(constrain(atoi(cmd+7), 0, 255));
    } else if (strncmp(cmd, "motor", 5) == 0) {
        int n = atoi(cmd+6); if (n<=0) n=3;
        motorBurstStart(n, 200, 55, 35);
    } else if (strcmp(cmd,"help")==0 || cmd[0]=='?') {
        printHelp();
    } else if (cmd[0] != '\0') {
        Serial.printf("Unknown: '%s'\n", cmd);
    }
}

void cliPoll() {
    while (Serial.available()) {
        char c = Serial.read();
        if (c=='\n'||c=='\r') {
            if (cliPos>0) { cliBuf[cliPos]='\0'; cliPos=0; handleCommand(cliBuf); }
        } else if (cliPos < sizeof(cliBuf)-1) {
            cliBuf[cliPos++] = c;
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════
void setup() {
    Serial.begin(115200);
    delay(300);
    Serial.println("\n=== Hand Unit ===");

    FastLED.addLeds<WS2812B, LED_PIN, GRB>(leds, LED_COUNT);
    FastLED.setBrightness(40);
    ledOff();

    ledcSetup(MOTOR_CH, MOTOR_FREQ, MOTOR_RES);
    ledcAttachPin(MOTOR_PIN, MOTOR_CH);
    ledcWrite(MOTOR_CH, 0);
    esp_timer_create_args_t targs = {};
    targs.callback = motorTimerCb; targs.name = "motor";
    esp_timer_create(&targs, &motorTimer);

    Wire.begin(TOF_SDA, TOF_SCL, TOF_FREQ);
    Wire1.begin(NFC_SDA, NFC_SCL, NFC_FREQ);

    pinMode(NFC_RST_PIN, OUTPUT);
    digitalWrite(NFC_RST_PIN, LOW);  delay(10);
    digitalWrite(NFC_RST_PIN, HIGH); delay(150);
    nfc.begin();
    uint32_t ver = nfc.getFirmwareVersion();
    if (!ver) {
        Serial.println("[NFC] not found — DIP SEL0=HIGH SEL1=LOW");
    } else {
        nfc.SAMConfig();
        nfc.setPassiveActivationRetries(0xFF);
        Serial.printf("[NFC] PN532 fw %u.%u ready\n", (ver>>16)&0xFF, (ver>>8)&0xFF);
        nfcReady = true;
    }

    pinMode(TOF_XSHUT, OUTPUT);
    digitalWrite(TOF_XSHUT, LOW);  delay(10);
    digitalWrite(TOF_XSHUT, HIGH); delay(10);
    tof.setTimeout(500);
    if (!tof.init()) {
        Serial.println("[TOF] not found");
    } else {
        tof.setSignalRateLimit(0.5);
        tof.startContinuous(50);
        Serial.println("[TOF] VL53L0X ready");
        tofReady = true;
    }

    nfcQueue = xQueueCreate(8, 20);
    if (nfcReady) {
        xTaskCreatePinnedToCore(nfcTask, "nfc", 4096, NULL, 1, NULL, 0);
        Serial.println("[NFC] task on Core 0");
    }

    ledSolid(nfcReady && tofReady ? CRGB(0,40,0) : CRGB(40,20,0));
    motorBurstStart(2, 160, 60, 40);
    delay(300);
    ledOff();
    ledMode = LedMode::IDLE;
    printHelp();
}

// ═══════════════════════════════════════════════════════════════
// LOOP — Core 1
// ═══════════════════════════════════════════════════════════════
uint32_t ledTimer    = 0;
uint32_t streamTimer = 0;

void loop() {
    uint32_t now = millis();

    cliPoll();

    // VL53L0X — non-blocking
    if (tofReady && (tof.readReg(0x13) & 0x07)) {
        uint16_t d = tof.readRangeContinuousMillimeters();
        if (!tof.timeoutOccurred()) {
            if      (d >= 8190 || d < 50) lastDist = 9999;
            else if (d <= 2000)           lastDist = d;
        }
    }

    // Proximity → motor (only when not in post-connection silence)
    if (touchState == TouchState::RELEASED) {
        motorProxSet(0);
        // Return to IDLE when silence has expired AND object has left the field
        if (now > silenceUntil && !distValid(lastDist)) {
            touchState = TouchState::IDLE;
            Serial.println("[Touch] Ready — new connection possible");
        }
    } else if (tofReady && distValid(lastDist) && lastDist < PROX_FAR_MM
               && ledMode == LedMode::IDLE) {
        float t = 1.0f - (float)(lastDist - PROX_NEAR_MM)
                         / (float)(PROX_FAR_MM - PROX_NEAR_MM);
        motorProxSet((uint8_t)(constrain(t,0.0f,1.0f) * t * MOTOR_MAX));
    } else {
        motorProxSet(0);
    }

    // NFC queue — connection event
    char uid[20] = {};
    if (xQueueReceive(nfcQueue, uid, 0) == pdTRUE) {
        Serial.printf("[NFC] Tag: %s\n", uid);
        if (touchState == TouchState::IDLE) {
            // Connection: double-click + enter silence
            Serial.printf("[Touch] Connection! Silence for %dms, then separate\n", SILENCE_MS);
            motorBurstStart(2, 230, 40, 30);    // double-click: 2 sharp pulses
            touchState  = TouchState::RELEASED;
            silenceUntil = now + SILENCE_MS;
            // White flash
            ledSolid(CRGB(200, 200, 200));
            delay(80);
        } else {
            // Already released — ignore until ready
            Serial.println("[Touch] Ignored — still in silence");
        }
    }

    // LED @ 25fps
    if (now - ledTimer >= 40) {
        ledTimer = now;
        switch (ledMode) {

            case LedMode::IDLE: {
                // Proximity factor: 0.0=far, 1.0=close
                // During RELEASED: stay at 0.0 (pure teal, no colour shift)
                float t = (touchState == TouchState::IDLE
                           && tofReady && distValid(lastDist) && lastDist < PROX_FAR_MM)
                    ? constrain(1.0f - (float)(lastDist - PROX_NEAR_MM)
                                / (float)(PROX_FAR_MM - PROX_NEAR_MM), 0.0f, 1.0f)
                    : 0.0f;

                // Colour weights computed once per frame (no per-LED float math)
                // Far: teal (0, 140, 200) → close: warm red (220, 40, 0)
                uint8_t rMax  = (uint8_t)(t * t * 220.0f);
                uint8_t gMax  = (uint8_t)((1.0f - t) * 140.0f);
                uint8_t bMax  = (uint8_t)((1.0f - t) * 200.0f);

                // Travelling wave using FastLED sin8() — integer lookup table, zero FPU
                // Period: 256 units × 15ms = 3.84s per full rotation for 8 LEDs
                // TWO_PI (double) caused software double-precision math → avoid entirely
                uint8_t phaseBase = (uint8_t)(now / 15);

                for (uint8_t i = 0; i < LED_COUNT; i++) {
                    // Each LED evenly spaced: 256/8 = 32 units apart
                    uint8_t phase = phaseBase + i * (256 / LED_COUNT);
                    // sin8: input 0-255 (full circle), output 0-255 (0.0-1.0)
                    uint8_t s = sin8(phase);
                    // Remap 0-255 → 15-230 for wide brightness range without zeros
                    uint8_t b = 15 + ((uint16_t)s * 215 / 255);
                    leds[i] = CRGB(
                        (uint16_t)rMax * b / 255,
                        (uint16_t)gMax * b / 255,
                        (uint16_t)bMax * b / 255
                    );
                }
                FastLED.show();
                break;
            }

            case LedMode::RAINBOW:
                fill_rainbow(leds, LED_COUNT, rainbowHue += 2, 256/LED_COUNT);
                FastLED.show();
                break;

            case LedMode::SOLID:
                fill_solid(leds, LED_COUNT, solidColor);
                FastLED.show();
                break;

            case LedMode::OFF:
                break;
        }
    }

    // VL53L0X stream
    if (streaming && tofReady && (now - streamTimer >= 100)) {
        streamTimer = now;
        uint8_t bars = (uint8_t)map(constrain(lastDist,0,500),0,500,30,0);
        char bar[32] = {}; memset(bar,'#',bars);
        Serial.printf("%4u mm  %s\n", lastDist, bar);
    }
}