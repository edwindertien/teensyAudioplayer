#pragma once

// ── NeoPixel ──────────────────────────────────────────────────
#define LED_PIN          4
#define LED_COUNT        8
#define LED_TYPE         WS2812B
#define LED_COLOR_ORDER  GRB

// ── Motor ─────────────────────────────────────────────────────
#define MOTOR_PIN   2
#define MOTOR_FREQ  20000
#define MOTOR_RES   8
#define MOTOR_CH    0
#define MOTOR_MAX   200

// ── I2C bus 0 — VL53L0X (Core 1 / main loop) ─────────────────
#define TOF_SDA     7
#define TOF_SCL     8
#define TOF_FREQ    400000
#define TOF_XSHUT   1

// ── I2C bus 1 — PN532 (Core 0 / NFC task) ────────────────────
// Move PN532 SDA→GPIO7, SCL→GPIO8
#define NFC_SDA     5
#define NFC_SCL     6
#define NFC_FREQ    400000
#define NFC_RST_PIN 21

// ── Proximity ─────────────────────────────────────────────────
#define PROX_FAR_MM   300
#define PROX_NEAR_MM  40